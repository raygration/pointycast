// See file LICENSE for more information.

part of api;

/// The interface that asymmetric private keys conform to.
abstract class PrivateKey implements AsymmetricKey {}

// See file LICENSE for more information.

part of api;

/// An interface for signatures created by a [Signer]
abstract class Signature {}

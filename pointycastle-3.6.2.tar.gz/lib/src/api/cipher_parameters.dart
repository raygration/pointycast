// See file LICENSE for more information.

part of api;

/// All cipher initialization parameters classes implement this.
abstract class CipherParameters {}

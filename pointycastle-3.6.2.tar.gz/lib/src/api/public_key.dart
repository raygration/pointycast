// See file LICENSE for more information.

part of api;

/// The interface that asymmetric public keys conform to.
abstract class PublicKey implements AsymmetricKey {}

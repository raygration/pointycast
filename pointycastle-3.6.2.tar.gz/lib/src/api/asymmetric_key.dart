// See file LICENSE for more information.

part of api;

/// The interface that asymmetric (public and private) keys conform to.
abstract class AsymmetricKey {}

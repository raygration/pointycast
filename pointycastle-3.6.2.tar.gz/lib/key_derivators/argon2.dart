export 'argon2_register64_impl.dart'
    if (dart.library.io) 'argon2_native_int_impl.dart';

// See file LICENSE for more information.

library benchmark.digests.tiger_benchmark;

import '../benchmark/digest_benchmark.dart';

void main() {
  DigestBenchmark('Tiger').report();
}

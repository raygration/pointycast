library benchmark.digests.blake2b_benchmark;

import '../benchmark/digest_benchmark.dart';

void main() {
  DigestBenchmark('Blake2b').report();
}
